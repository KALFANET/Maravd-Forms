import { useState, useEffect } from 'react';
... (full useAuth hook code)
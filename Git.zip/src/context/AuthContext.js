import React, { createContext, useContext, useState } from 'react';
... (full AuthContext code)
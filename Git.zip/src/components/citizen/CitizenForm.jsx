import React, { useState } from 'react';
... (full CitizenForm code)